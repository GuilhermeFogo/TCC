﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using ProjetoTCCAutomacao.Mapemento.Google;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace ProjetoTCCXUnit.Teste.Google
{
    public class LoginGoogleTest : IDisposable
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        public LoginGoogleTest()
        {
            this.driver = new ChromeDriver();
            this.driver.Navigate().GoToUrl("https://www.google.com.br/");
            this.wait = new WebDriverWait(driver, new TimeSpan(0, 1, 0));
        }

        public void Dispose()
        {
            this.driver.Quit();
        }

        [Fact]
        public void EmailsInvalidos()
        {
            var loguin = new LoginGoogle(this.driver, wait);

            if (loguin.ExistBTNLogin())
            {
                loguin.ClickBtnLogin();
                loguin.PreencherCampoEmail("fiuodshjfds@gmail.com");
                loguin.ClickBtnProximo();
                var erro = loguin.MensagemErroUsuario();
                var menagemPadrao = "Digite um e-mail ou número de telefone válido";
                var menagemPadrao1 = "Não foi possível encontrar sua Conta do Google";
                try
                {
                    Assert.Equal(menagemPadrao, erro);
                }
                catch (Exception)
                {
                    Assert.Equal(menagemPadrao1, erro);
                }
            }
            else
            {
                Assert.False(true);
            }
        }

        //[Fact]
        //public void SenhaInvalida()
        //{
        //    var loguin = new LoginGoogle(this.driver, wait);

        //    if (loguin.ExistBTNLogin())
        //    {
        //        loguin.ClickBtnLogin();
        //        loguin.PreencherCampoEmail("teste@gmail.com");
        //        loguin.ClickBtnProximo();
        //        loguin.PreecherCampoSenha("abc123");
        //        var erro = loguin.MensagemErroSenha();
        //        var menagemPadrao = "Senha incorreta. Tente novamente ou clique em 'Esqueceu a senha ?' para redefini-la";

        //        Assert.Equal(menagemPadrao, erro);
        //    }
        //    else
        //    {
        //        Assert.False(true);
        //    }
        //}
    }
}
