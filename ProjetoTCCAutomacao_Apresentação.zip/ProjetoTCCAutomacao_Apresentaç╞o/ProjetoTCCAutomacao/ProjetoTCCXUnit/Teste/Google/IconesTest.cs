﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using ProjetoTCCAutomacao.Mapemento.Google;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace ProjetoTCCAutomacao.Test.Google
{
    public class IconesTest : IDisposable
    {

        private IWebDriver driver;
        private WebDriverWait wait;
        public IconesTest()
        {
            this.driver = new ChromeDriver();
            this.driver.Navigate().GoToUrl("https://www.google.com.br/");
            this.wait = new WebDriverWait(driver, new TimeSpan(0, 1, 0));
        }

        public void Dispose()
        {

            this.driver.Quit();
        }

        [Fact]
        public void ExisteIconeTeclado()
        {
            var icones = new GoogleIcones(this.driver, wait);

            Assert.True(icones.ExistIconeTeclado(0));
        }

        [Fact]
        public void TecladoAparece()
        {
            var icones = new GoogleIcones(this.driver, wait);
            if (icones.ExistIconeTeclado(0))
            {
                icones.ClickIconeTeclado(0);
                Assert.True(icones.ExistTeclado());
            }
            else
            {
                Assert.False(true);
            }
        }
    }
}
