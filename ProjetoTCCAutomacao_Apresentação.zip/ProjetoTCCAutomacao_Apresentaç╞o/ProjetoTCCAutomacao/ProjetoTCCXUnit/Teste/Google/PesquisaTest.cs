﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using ProjetoTCCAutomacao.Mapemento.Google;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace ProjetoTCCAutomacao.Test.Google
{
    public class PesquisaTest : IDisposable
    {
        private IWebDriver driver;
        private WebDriverWait wait;
        public PesquisaTest()
        {
            this.driver = new ChromeDriver();
            this.driver.Navigate().GoToUrl("https://www.google.com.br/");
            this.wait = new WebDriverWait(driver, new TimeSpan(0, 1, 0));
        }

        public void Dispose()
        {
            this.driver.Quit();
        }

        [Theory]
        [InlineData("youtube", "https://www.youtube.com/?hl=pt&gl=BR")]
        [InlineData("submarino", "https://www.submarino.com.br/")]
        [InlineData("americanas", "https://www.americanas.com.br/")]
        [InlineData("viajanet", "https://www.viajanet.com.br/")]
        [InlineData("alura", "https://www.alura.com.br/")]
        [InlineData("metodista", "https://metodista.br/")]
        [InlineData("uol", "https://www.uol.com.br/")]
        public void Pesquisar(string site, string link)
        {
            var google = new PesquisaGoogle(driver);
            if (google.ExisteCampoGoogle())
            {
                google.PreencherCampoGoogle(site);
                google.ClickPesquisar(1);
                google.ClickResultado(0);
            }
            else
            {
                Assert.False(false);
            }

            var linkVerificado = this.driver.Url.Equals(link);
            Assert.True(linkVerificado);
        }

        [Theory]
        [InlineData("youtube", "YouTube")]
        [InlineData("submarino", "Submarino")]
        [InlineData("americanas", "Americanas")]
        [InlineData("viajanet", "ViajaNet")]
        [InlineData("alura", "Alura")]
        [InlineData("metodista", "Metodista")]
        [InlineData("uol", "UOL")]
        public void VerNomedoSite(string sites, string nomeSite)
        {
            var google = new PesquisaGoogle(driver);
            if (google.ExisteCampoGoogle())
            {
                google.PreencherCampoGoogle(sites);
                google.ClickPesquisar(1);
                var site = google.PegarNomedoSite(0);
                var verifica = site.Contains(nomeSite);

                Assert.True(verifica);
            }

        }
    }
}
