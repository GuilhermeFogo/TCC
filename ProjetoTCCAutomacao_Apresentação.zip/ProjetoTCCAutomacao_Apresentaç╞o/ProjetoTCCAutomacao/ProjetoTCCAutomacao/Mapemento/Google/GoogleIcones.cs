﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace ProjetoTCCAutomacao.Mapemento.Google
{
    public class GoogleIcones
    {
        public readonly IWebDriver driver;
        private readonly WebDriverWait wait;
        private IJavaScriptExecutor javaScriptExecutor;
        public GoogleIcones(IWebDriver driver, WebDriverWait wait)
        {
            this.driver = driver;
            this.wait = wait;

            this.javaScriptExecutor = (IJavaScriptExecutor)driver;
        }

        private ReadOnlyCollection<IWebElement> IconeTeclado => this.driver.FindElements(By.ClassName("hOoLGe"));
        private IWebElement Teclado => this.driver.FindElement(By.Id("kbd"));


        public bool ExistIconeTeclado(int index)
        {
            try
            {
                return IconeTeclado[index].Displayed;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool ExistTeclado()
        {
            try
            {
                this.wait.Until(ExpectedConditions.ElementExists(By.Id("kbd")));
                return Teclado.Displayed;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void ClickIconeTeclado(int index)
        {
            try
            {
                IconeTeclado[index].Click();
            }
            catch (Exception)
            {
                string js = "document.querySelector('.hOoLGe').click()";
                javaScriptExecutor.ExecuteScript(js);
            }
        }
    }
}
