﻿namespace ProjetoTCCAutomacao.Mapemento.Google
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Text;

    public class PesquisaGoogle
    {
        public readonly IWebDriver driver;
        private IJavaScriptExecutor javaScriptExecutor;
        public PesquisaGoogle(IWebDriver driver)
        {
            this.driver = driver;
            
            this.javaScriptExecutor = (IJavaScriptExecutor) driver;
        }

        private ReadOnlyCollection<IWebElement> ResultadoPesquisaGoogle => driver.FindElements(By.ClassName("LC20lb"));
        private IWebElement CampooGoogle => driver.FindElement(By.Name("q"));

        private ReadOnlyCollection<IWebElement> BtnPesquisar => driver.FindElements(By.ClassName("gNO89b"));


        public bool ExisteCampoGoogle()
        {
            try
            {
                return this.CampooGoogle.Displayed;
            }
            catch (WebDriverException)
            {
                return false;
            }
        }

        public void PreencherCampoGoogle(string valor)
        {
            this.CampooGoogle.SendKeys(valor);
        }

        public string PegarNomedoSite(int index)
        {
            try
            {
                return this.ResultadoPesquisaGoogle[index].Text;
            }
            catch (Exception)
            {
                string comand = $"document.getElementsByClassName('S3Uucc')[{index}].innerText;";
                return this.javaScriptExecutor.ExecuteScript(comand).ToString();
            }
        }

        public void ClickResultado(int index)
        {
            try
            {
                this.ResultadoPesquisaGoogle[index].Click();
            }
            catch (Exception)
            {
                string comando = $"document.getElementsByClassName('LC20lb')[{index}].click();";
                javaScriptExecutor.ExecuteScript(comando);
            }
        }


        public void ClickPesquisar(int index)
        {
            try
            {
                this.BtnPesquisar[index].Click();
            }
            catch (Exception)
            {
                javaScriptExecutor.ExecuteScript($"document.getElementsByClassName('gNO89b')[{index}].click()");
            }
        }
    }
}
