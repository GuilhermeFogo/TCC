﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoTCCAutomacao.Mapemento.Google
{
    public class LoginGoogle
    {
        public readonly IWebDriver driver;
        private readonly WebDriverWait wait;
        private IJavaScriptExecutor javaScriptExecutor;
        public LoginGoogle(IWebDriver driver, WebDriverWait wait)
        {
            this.driver = driver;
            this.wait = wait;

            this.javaScriptExecutor = (IJavaScriptExecutor)driver;
        }

        private IWebElement BtnLogin => this.driver.FindElement(By.Id("gb_70"));
        private IWebElement CampoEmail => this.driver.FindElement(By.Id("identifierId"));

        private IWebElement BtnProximo => this.driver.FindElement(By.ClassName("VfPpkd-RLmnJb"));
        private IWebElement CampoSenha => this.driver.FindElement(By.ClassName("whsOnd"));
        private IWebElement MensagemErro1 => this.driver.FindElement(By.ClassName("o6cuMc"));
        private IWebElement MensagemErro2 => this.driver.FindElement(By.XPath("#view_container > div > div > div.pwWryf.bxPAYd > div > div.WEQkZc > div > form > span > section > div > div > div.SdBahf.VxoKGd.Jj6Lae > div.OyEIQ.uSvLId > div:nth-child(2)"));



        public string MensagemErroSenha()
        {
            try
            {
                this.wait.Until(ExpectedConditions.ElementExists(By.XPath("#view_container > div > div > div.pwWryf.bxPAYd > div > div.WEQkZc > div > form > span > section > div > div > div.SdBahf.VxoKGd.Jj6Lae > div.OyEIQ.uSvLId > div:nth-child(2)")));
                return MensagemErro2.Text;
            }
            catch (Exception)
            {
                string js = "document.querySelector('#view_container > div > div > div.pwWryf.bxPAYd > div > div.WEQkZc > div > form > span > section > div > div > div.SdBahf.VxoKGd.Jj6Lae > div.OyEIQ.uSvLId > div:nth-child(2)').innerText";
                return javaScriptExecutor.ExecuteScript(js).ToString();
            }
        }
        public string MensagemErroUsuario()
        {
            try
            {
                this.wait.Until(ExpectedConditions.ElementExists(By.ClassName("o6cuMc")));
                return MensagemErro1.Text;
            }
            catch (Exception)
            {
                string js = "document.querySelector('.o6cuMc').innerText";
                return javaScriptExecutor.ExecuteScript(js).ToString();
            }
        }

        public void PreecherCampoSenha(string valor)
        {
            this.CampoSenha.SendKeys(valor);
        }

        public  bool ExistCampoSenha()
        {
            try
            {
                this.wait.Until(ExpectedConditions.ElementExists(By.ClassName("whsOnd")));
                return CampoSenha.Displayed;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public void ClickBtnProximo()
        {
            try
            {
                this.BtnProximo.Click();
            }
            catch (Exception)
            {
                string js = "document.querySelector('.VfPpkd-RLmnJb')";
                javaScriptExecutor.ExecuteScript(js);
            }
        }

        public bool ExistCampoEmail()
        {
            try
            {
                return this.CampoEmail.Displayed;
            }
            catch (Exception)
            {
                return false;
            }
        }


        public void PreencherCampoEmail(string valor)
        {
            this.CampoEmail.SendKeys(valor);
        }
        public bool ExistBTNLogin()
        {
            try
            {
                return this.BtnLogin.Displayed;
            }
            catch (Exception)
            {
                return false;
            }
        }


        public void ClickBtnLogin()
        {
            try
            {
                this.BtnLogin.Click();
            }
            catch (Exception)
            {
                string javascript = "document.getElementById('gb_70').click()";
                this.javaScriptExecutor.ExecuteScript(javascript);
            }
        }
    }
}
