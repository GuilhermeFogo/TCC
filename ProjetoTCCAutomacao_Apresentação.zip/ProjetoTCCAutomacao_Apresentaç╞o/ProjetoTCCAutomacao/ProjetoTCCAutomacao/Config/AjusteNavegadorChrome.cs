﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoTCCAutomacao.Config
{
    public abstract class AjusteNavegadorChrome
    {
        private IWebDriver driver;
        public IWebDriver AbriPagina(string AbrirPagina)
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(AbrirPagina);
            return driver;
        }


        public IWebDriver AbrirPaginaMaximizada(string AbrirPagina)
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArguments("start-maximized");
            driver = new ChromeDriver(options);
            driver.Navigate().GoToUrl(AbrirPagina);
            return driver;
        }


    }
}
